plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.carpool"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.carpool"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"


    }


    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Android support libraries
    implementation(libs.appcompat)              // For support of modern Android UI components
    implementation(libs.material)               // For Material Components
    implementation(libs.activity)               // For Activity components
    implementation(libs.constraintlayout)      // For ConstraintLayout

    // Google Play Services for Maps and Location
    implementation("com.google.android.gms:play-services-maps:18.2.0")  // Google Maps SDK
    implementation("com.google.android.gms:play-services-location:18.0.0") // For location services (if using)

    // Retrofit dependencies
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    // RecyclerView for displaying news articles
    implementation("androidx.recyclerview:recyclerview:1.2.1")

    // Gson for JSON parsing
    implementation("com.google.code.gson:gson:2.8.8")

    // Unit and UI testing libraries
    testImplementation(libs.junit)             // For unit testing
    androidTestImplementation(libs.ext.junit)  // For UI testing
    androidTestImplementation(libs.espresso.core) // For Espresso UI tests
}
